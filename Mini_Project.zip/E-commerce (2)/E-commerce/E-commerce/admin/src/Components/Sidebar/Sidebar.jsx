// Sidebar.jsx
import React from 'react';
import './Sidebar.css';
import { NavLink } from 'react-router-dom';

const Sidebar = () => {
  return (
    <div className='sidebar'>
      <h2 className='sidebar-title'>Admin Dashboard</h2>

      <NavLink to='/admin/addproduct' className='sidebar-item' activeclassname='active-link'>
        <span>Add Product</span>
      </NavLink>

      <NavLink to='/admin/listproduct' className='sidebar-item' activeclassname='active-link'>
        <span>Product List</span>
      </NavLink>

      <NavLink to='/admin/dashboard' className='sidebar-item' activeclassname='active-link'>
        <span>Dashboard</span>
      </NavLink>

      <NavLink to='/admin/users' className='sidebar-item' activeclassname='active-link'>
        <span>Users</span>
      </NavLink>
    </div>
  );
};

export default Sidebar;
