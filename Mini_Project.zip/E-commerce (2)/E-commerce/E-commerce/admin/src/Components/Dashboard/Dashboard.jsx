import React from 'react';
import './Dashboard.css';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';

const Dashboard = () => {
  const data = [
    { name: 'Jan', sales: 2400 },
    { name: 'Feb', sales: 1398 },
    { name: 'Mar', sales: 9800 },
    { name: 'Apr', sales: 3908 },
    { name: 'May', sales: 4800 },
    { name: 'Jun', sales: 3800 },
  ];

  return (
    <div className="dashboard">
      <h2>Admin Overview</h2>
      <div className="summary-cards">
        <div className="summary-card">
          <h3>Total Sales</h3>
          <p>₹25,000</p>
        </div>
        <div className="summary-card">
          <h3>Revenue</h3>
          <p>₹18,500</p>
        </div>
        <div className="summary-card">
          <h3>Profit</h3>
          <p>₹6,500</p>
        </div>
      </div>
      <div className="chart-box">
        <h3>Monthly Sales</h3>
        <LineChart width={600} height={300} data={data}>
          <CartesianGrid stroke="#ccc" />
          <XAxis dataKey="name" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Line type="monotone" dataKey="sales" stroke="#6079ff" />
        </LineChart>
      </div>
    </div>
  );
};

export default Dashboard;
