import React, { useState } from 'react';
import Navbar from './Components/Navbar/Navbar';
import Admin from './Pages/Admin/Admin';
import AdminLogin from './Pages/Admin/AdminLogin';
import { Routes, Route, Navigate } from 'react-router-dom';

const App = () => {
  const [adminAuthenticated, setAdminAuthenticated] = useState(false);

  return (
    <>
      <Navbar />
      <Routes>
        {/* Admin Route: Shows login or dashboard based on auth */}
        <Route
          path="/admin/*"
          element={
            adminAuthenticated ? (
              <Admin />
            ) : (
              <AdminLogin onLogin={() => setAdminAuthenticated(true)} />
            )
          }
        />

        {/* Optional: redirect home route to /admin */}
        <Route path="/" element={<Navigate to="/admin" />} />
      </Routes>
    </>
  );
};

export default App;
