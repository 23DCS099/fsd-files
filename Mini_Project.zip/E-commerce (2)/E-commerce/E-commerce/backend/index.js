// Final Updated Backend Code with Fixed Cart Functionality

const port = 4000;
const express = require("express");
const app = express();
const mongoose = require("mongoose");
const jwt = require("jsonwebtoken");
const multer = require("multer");
const path = require("path");
const cors = require("cors");
const stripe = require("stripe")("sk_test_51RasrURF7uvcW0SWFv2IYiFwVssSZakiT1ywNau90IzigAuZ6KauLSeCycMgUzOecuMkRiOH1QkqyojNxFZtHb0500OSLtsZtC");

app.use(express.json());
app.use(cors());

// MongoDB Connection
mongoose.connect("mongodb+srv://23dcs120:Parth%402005@cluster0.kjdtt9j.mongodb.net/e-commerce");

// Serve static images
app.use('/images', express.static('upload/images'));

// Multer image upload setup
const storage = multer.diskStorage({
  destination: './upload/images',
  filename: (req, file, cb) => {
    cb(null, `${file.fieldname}_${Date.now()}${path.extname(file.originalname)}`);
  }
});
const upload = multer({ storage });

// Function to generate unique description based on product details
const generateDescription = (product) => {
  const categories = {
    'men': ['men\'s', 'gentlemen\'s', 'masculine'],
    'women': ['women\'s', 'ladies\'', 'feminine'],
    'kid': ['kids\'', 'children\'s', 'youth']
  };
  
  const clothTypes = {
    'shirt': ['shirt', 'top', 'garment'],
    'pants': ['pants', 'trousers', 'bottoms'],
    'dress': ['dress', 'gown', 'outfit'],
    'hoodie': ['hoodie', 'sweatshirt', 'pullover'],
    'jacket': ['jacket', 'coat', 'outerwear'],
    'jeans': ['jeans', 'denim', 'pants'],
    'tshirt': ['t-shirt', 'tee', 'top'],
    'sweater': ['sweater', 'jumper', 'pullover']
  };
  
  const category = categories[product.category] || ['fashion'];
  const clothType = clothTypes[product.clothType] || ['clothing'];
  const style = product.brand ? `from ${product.brand}` : 'fashionable';
  
  const descriptions = [
    `Premium ${category[0]} ${clothType[0]} designed for comfort and style. This ${style} piece features modern design elements perfect for everyday wear.`,
    `Stylish ${category[1]} ${clothType[1]} that combines elegance with functionality. Made with quality materials for lasting durability and comfort.`,
    `Contemporary ${category[2]} ${clothType[2]} offering both comfort and sophistication. Perfect for casual and semi-formal occasions.`,
    `Trendy ${category[0]} ${clothType[0]} with a modern twist. Features innovative design that stands out while maintaining comfort.`,
    `Classic ${category[1]} ${clothType[1]} with contemporary styling. Ideal for those who appreciate timeless fashion with modern touches.`
  ];
  
  // Generate unique description based on product ID and details
  const index = (product.id || Math.random()) % descriptions.length;
  return descriptions[index];
};

// Upload endpoint
app.post("/upload", upload.single('product'), (req, res) => {
  res.json({
    success: 1,
    image_url: `http://localhost:${port}/images/${req.file.filename}`
  });
});

// Base route
app.get("/", (req, res) => res.send("Express App is Running"));

// Product Schema and Model
const Product = mongoose.model("Product", {
  id: Number,
  name: String,
  image: String,
  category: String,
  new_price: Number,
  old_price: Number,
  description: String,     
  brand: String,           
  clothType: String,
  sizes: [String], // Array of available sizes
  date: { type: Date, default: Date.now },
  available: { type: Boolean, default: true }
});

// Add product with automatic description generation
app.post('/addproduct', async (req, res) => {
  try {
    const products = await Product.find({});
    const id = products.length > 0 ? products[products.length - 1].id + 1 : 1;
    
    // Generate description if not provided
    let description = req.body.description;
    if (!description) {
      description = generateDescription({ ...req.body, id });
    }
    
    // Set default sizes if not provided
    const sizes = req.body.sizes || ['S', 'M', 'L', 'XL', 'XXL'];
    
    // Set default clothType if not provided
    const clothType = req.body.clothType || 'clothing';
    
    const product = new Product({ 
      id, 
      ...req.body, 
      description,
      sizes,
      clothType
    });
    
    await product.save();
    res.json({ success: true, name: req.body.name, id });
  } catch (error) {
    console.error("Add product error:", error);
    res.status(500).json({ success: false, error: "Failed to add product" });
  }
});

// Remove product
app.post('/removeproduct', async (req, res) => {
  await Product.findOneAndDelete({ id: req.body.id });
  res.json({ success: true });
});

// Get all products
app.get('/allproducts', async (req, res) => {
  const products = await Product.find({});
  res.send(products);
});

// Update existing products with proper sizes
app.post('/update-product-sizes', async (req, res) => {
  try {
    // Update Men's products (IDs 13-24)
    const menSizes = ['S', 'M', 'L', 'XL', 'XXL'];
    await Product.updateMany(
      { category: 'men', $or: [{ sizes: { $exists: false } }, { sizes: { $size: 0 } }] },
      { $set: { sizes: menSizes } }
    );

    // Update Kids products (IDs 25-36) 
    const kidsSizes = ['2-3Y', '4-5Y', '6-7Y', '8-9Y'];
    await Product.updateMany(
      { category: 'kid', $or: [{ sizes: { $exists: false } }, { sizes: { $size: 0 } }] },
      { $set: { sizes: kidsSizes } }
    );

    // Update Women's products that might be missing sizes
    const womenSizes = ['XS', 'S', 'M', 'L', 'XL'];
    await Product.updateMany(
      { category: 'women', $or: [{ sizes: { $exists: false } }, { sizes: { $size: 0 } }] },
      { $set: { sizes: womenSizes } }
    );

    res.json({ success: true, message: "Product sizes updated successfully" });
  } catch (error) {
    console.error("Update sizes error:", error);
    res.status(500).json({ success: false, error: "Failed to update product sizes" });
  }
});

// Add sample products for testing
app.post('/add-sample-products', async (req, res) => {
  try {
    const sampleProducts = [
      // Men's Section - Different names, prices, descriptions
      {
        name: "Men's Classic Denim Jacket",
        category: "men",
        new_price: 1200,
        old_price: 1500,
        brand: "DenimCo",
        clothType: "jacket",
        sizes: ["S", "M", "L", "XL"],
        description: "Classic denim jacket with modern styling. Perfect for casual wear and outdoor activities. Features comfortable fit and durable construction.",
        image: "http://localhost:4000/images/product_1.png"
      },
      {
        name: "Men's Formal White Shirt",
        category: "men",
        new_price: 900,
        old_price: 1200,
        brand: "FormalWear",
        clothType: "shirt",
        sizes: ["S", "M", "L", "XL", "XXL"],
        description: "Premium formal white shirt. Perfect for office wear and formal occasions. Made with high-quality cotton for breathability.",
        image: "http://localhost:4000/images/product_2.png"
      },
      {
        name: "Men's Sports Hoodie",
        category: "men",
        new_price: 800,
        old_price: 1100,
        brand: "SportStyle",
        clothType: "hoodie",
        sizes: ["M", "L", "XL", "XXL"],
        description: "Comfortable sports hoodie perfect for workouts and casual wear. Features moisture-wicking fabric and adjustable hood."
      },
      {
        name: "Men's Casual T-Shirt",
        category: "men",
        new_price: 450,
        old_price: 600,
        brand: "CasualWear",
        clothType: "tshirt",
        sizes: ["S", "M", "L", "XL"],
        description: "Soft cotton casual t-shirt with modern design. Perfect for everyday wear and comfortable fit."
      },

      // Women's Section - Different names, prices, descriptions
      {
        name: "Women's Floral Summer Dress",
        category: "women",
        new_price: 800,
        old_price: 1000,
        brand: "SummerStyle",
        clothType: "dress",
        sizes: ["XS", "S", "M", "L"],
        description: "Beautiful floral print summer dress. Lightweight and comfortable for warm weather. Perfect for casual outings and parties.",
        image: "http://localhost:4000/images/product_10.png"
      },
      {
        name: "Women's High-Waist Jeans",
        category: "women",
        new_price: 1100,
        old_price: 1400,
        brand: "JeansPro",
        clothType: "jeans",
        sizes: ["26", "28", "30", "32", "34"],
        description: "Stylish high-waist jeans with stretch comfort. Perfect for everyday wear. Features modern fit and comfortable stretch fabric."
      },
      {
        name: "Women's Blouse Top",
        category: "women",
        new_price: 650,
        old_price: 850,
        brand: "ElegantWear",
        clothType: "shirt",
        sizes: ["XS", "S", "M", "L", "XL"],
        description: "Elegant blouse top perfect for office and casual wear. Features modern design and comfortable fit."
      },
      {
        name: "Women's Winter Sweater",
        category: "women",
        new_price: 950,
        old_price: 1200,
        brand: "WinterCo",
        clothType: "sweater",
        sizes: ["S", "M", "L"],
        description: "Warm and cozy winter sweater. Perfect for cold weather. Made with soft wool blend for maximum comfort."
      },

      // Kids Section - Different names, prices, descriptions
      {
        name: "Kids' Cartoon T-Shirt",
        category: "kid",
        new_price: 400,
        old_price: 500,
        brand: "FunKids",
        clothType: "tshirt",
        sizes: ["2-3Y", "4-5Y", "6-7Y", "8-9Y"],
        description: "Fun cartoon printed t-shirt for kids. Made with soft cotton for comfort. Perfect for daily wear and playtime.",
        image: "http://localhost:4000/images/product_20.png"
      },
      {
        name: "Kids' Denim Shorts",
        category: "kid",
        new_price: 550,
        old_price: 700,
        brand: "KidsDenim",
        clothType: "shorts",
        sizes: ["2-3Y", "4-5Y", "6-7Y", "8-9Y"],
        description: "Comfortable denim shorts for kids. Perfect for summer and casual wear. Features adjustable waistband."
      },
      {
        name: "Kids' Winter Jacket",
        category: "kid",
        new_price: 750,
        old_price: 950,
        brand: "KidsWear",
        clothType: "jacket",
        sizes: ["2-3Y", "4-5Y", "6-7Y", "8-9Y"],
        description: "Warm winter jacket for kids. Perfect for cold weather. Features waterproof material and comfortable lining."
      },
      {
        name: "Kids' Party Dress",
        category: "kid",
        new_price: 600,
        old_price: 800,
        brand: "PartyKids",
        clothType: "dress",
        sizes: ["2-3Y", "4-5Y", "6-7Y", "8-9Y"],
        description: "Beautiful party dress for special occasions. Features elegant design and comfortable fabric. Perfect for celebrations."
      }
    ];

    for (const product of sampleProducts) {
      const products = await Product.find({});
      const id = products.length > 0 ? products[products.length - 1].id + 1 : 1;
      
      const newProduct = new Product({ 
        id, 
        ...product,
        date: new Date()
      });
      
      await newProduct.save();
    }

    res.json({ success: true, message: "Sample products added successfully" });
  } catch (error) {
    console.error("Add sample products error:", error);
    res.status(500).json({ success: false, error: "Failed to add sample products" });
  }
});

// User Schema and Model
const Users = mongoose.model('Users', {
  name: String,
  email: { type: String, unique: true },
  password: String,
  phone: String,
  address: {
    street: String,
    city: String,
    state: String,
    zipCode: String,
    country: String
  },
  profile: {
    firstName: String,
    lastName: String,
    dateOfBirth: Date,
    gender: String,
    profileImage: String
  },
  cartData: {
    type: Object,
    default: () => {
      const cart = {};
      for (let i = 0; i < 300; i++) cart[i] = 0;
      return cart;
    }
  },
  date: { type: Date, default: Date.now }
});

// Order Schema and Model
const Order = mongoose.model('Order', {
  orderId: { type: String, unique: true },
  userId: String,
  items: [{
    productId: Number,
    productName: String,
    productImage: String,
    size: String,
    quantity: Number,
    price: Number
  }],
  totalAmount: Number,
  shippingAddress: {
    street: String,
    city: String,
    state: String,
    zipCode: String,
    country: String
  },
  paymentMethod: String,
  paymentStatus: { type: String, default: 'pending' },
  orderStatus: { type: String, default: 'placed' },
  trackingNumber: String,
  statusHistory: [{
    status: String,
    timestamp: { type: Date, default: Date.now },
    note: String
  }],
  orderDate: { type: Date, default: Date.now },
  estimatedDelivery: Date,
  actualDelivery: Date
});

// Signup
app.post("/signup", async (req, res) => {
  try {
    const check = await Users.findOne({ email: req.body.email });
    if (check) return res.status(400).json({ success: false, errors: "Email already exists" });

    const user = new Users({
      name: req.body.username,
      email: req.body.email,
      password: req.body.password
    });

    await user.save();
    const data = { user: { id: user.id } };
    const token = jwt.sign(data, 'secret_ecom');
    res.json({ success: true, token });
  } catch (error) {
    console.error("Signup error:", error);
    res.status(500).json({ success: false, error: "Internal Server Error" });
  }
});

// Login
app.post("/login", async (req, res) => {
  const user = await Users.findOne({ email: req.body.email });
  if (user && req.body.password === user.password) {
    const data = { user: { id: user.id } };
    const token = jwt.sign(data, 'secret_ecom');
    res.json({ success: true, token });
  } else {
    res.json({ success: false, errors: "Invalid credentials" });
  }
});

// Collections
app.get('/newcollections', async (req, res) => {
  const products = await Product.find({});
  res.send(products.slice(-8));
});

app.get('/popularinwomen', async (req, res) => {
  const products = await Product.find({ category: "women" });
  res.send(products.slice(0, 4));
});

// Middleware for protected routes
const fetchUser = async (req, res, next) => {
  const token = req.header('auth-token');
  if (!token) return res.status(401).send({ errors: "No token provided" });
  try {
    const data = jwt.verify(token, 'secret_ecom');
    req.user = data.user;
    next();
  } catch (error) {
    res.status(401).send({ errors: "Invalid token" });
  }
};

// Add to cart with size and quantity support
app.post('/addtocart', fetchUser, async (req, res) => {
  try {
    const userData = await Users.findOne({ _id: req.user.id });
    const { itemId, quantity = 1, size = null } = req.body;
    
    if (!itemId && itemId !== 0) return res.status(400).json({ success: false, message: "Invalid itemId" });
    if (quantity < 1 || quantity > 10) return res.status(400).json({ success: false, message: "Invalid quantity" });

    if (!userData.cartData) userData.cartData = {};
    if (!userData.cartData[itemId]) userData.cartData[itemId] = 0;
    userData.cartData[itemId] += quantity;

    await Users.findOneAndUpdate({ _id: req.user.id }, { cartData: userData.cartData });
    res.json({ 
      success: true, 
      message: `Added ${quantity} item(s) to cart${size ? ` (Size: ${size})` : ''}`,
      itemId,
      quantity,
      size
    });
  } catch (err) {
    console.error("Error in /addtocart:", err);
    res.status(500).json({ success: false, error: "Server Error" });
  }
});

// Remove from cart
app.post('/removefromcart', fetchUser, async (req, res) => {
  console.log("removed", req.body.itemId);
  let userData = await Users.findOne({ _id: req.user.id });
  if (userData.cartData[req.body.itemId] > 0)
    userData.cartData[req.body.itemId] -= 1;
  await Users.findOneAndUpdate({ _id: userData._id }, { cartData: userData.cartData });
  res.send("Removed");
});


// Get cart
app.post('/getcart', fetchUser, async (req, res) => {
  try {
    const user = await Users.findById(req.user.id);
    res.json({ success: true, cart: user.cartData });
  } catch (err) {
    console.error("Get cart error:", err);
    res.status(500).json({ success: false, error: "Internal Server Error" });
  }
});

// Get user profile
app.get('/profile', fetchUser, async (req, res) => {
  try {
    const user = await Users.findById(req.user.id);
    if (!user) {
      return res.status(404).json({ success: false, error: "User not found" });
    }
    
    // Return user data without password
    const { password, ...userData } = user.toObject();
    res.json({ success: true, user: userData });
  } catch (err) {
    console.error("Get profile error:", err);
    res.status(500).json({ success: false, error: "Internal Server Error" });
  }
});

// Update user profile
app.put('/profile', fetchUser, async (req, res) => {
  try {
    const { name, phone, address, profile } = req.body;
    const updateData = {};
    
    if (name) updateData.name = name;
    if (phone) updateData.phone = phone;
    if (address) updateData.address = address;
    if (profile) updateData.profile = profile;
    
    const user = await Users.findByIdAndUpdate(
      req.user.id,
      updateData,
      { new: true, runValidators: true }
    );
    
    if (!user) {
      return res.status(404).json({ success: false, error: "User not found" });
    }
    
    const { password, ...userData } = user.toObject();
    res.json({ success: true, user: userData, message: "Profile updated successfully" });
  } catch (err) {
    console.error("Update profile error:", err);
    res.status(500).json({ success: false, error: "Internal Server Error" });
  }
});

// Stripe payment (Card)
app.post("/api/payment/create-checkout-session", async (req, res) => {
  try {
    const { amount, items, shippingAddress, userId } = req.body;
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      mode: 'payment',
      line_items: [{
        price_data: {
          currency: 'inr',
          product_data: { name: "Swagsy Order" },
          unit_amount: amount * 100,
        },
        quantity: 1,
      }],
      success_url: `http://localhost:3000/payment-done?session_id={CHECKOUT_SESSION_ID}&userId=${userId}`,
      cancel_url: 'http://localhost:3000/cancel',
      metadata: {
        userId: userId,
        items: JSON.stringify(items),
        shippingAddress: JSON.stringify(shippingAddress),
        amount: amount.toString()
      }
    });
    res.status(200).json({ url: session.url });
  } catch (err) {
    console.error("Stripe error:", err);
    res.status(500).send("Payment session creation failed");
  }
});

// Handle successful payment and create order
app.post("/api/payment/success", async (req, res) => {
  try {
    const { sessionId, userId, items, shippingAddress, amount, paymentMethod } = req.body;
    
    // Generate unique order ID
    const orderId = `ORD-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
    
    // Create order
    const order = new Order({
      orderId,
      userId: userId,
      items: items,
      totalAmount: amount,
      shippingAddress: shippingAddress,
      paymentMethod: paymentMethod || 'Card',
      paymentStatus: 'completed',
      orderStatus: 'placed',
      trackingNumber: `TRK-${Date.now()}`,
      statusHistory: [{
        status: 'placed',
        note: 'Order has been placed successfully'
      }],
      estimatedDelivery: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) // 7 days from now
    });
    
    await order.save();
    
    // Clear user's cart after successful order
    await Users.findByIdAndUpdate(userId, {
      cartData: {}
    });
    
    res.json({ 
      success: true, 
      order: order,
      message: "Order created successfully" 
    });
  } catch (err) {
    console.error("Payment success error:", err);
    res.status(500).json({ success: false, error: "Failed to create order" });
  }
});

// UPI Payment
app.post("/api/payment/upi", async (req, res) => {
  try {
    const { amount, upiId, customerName, customerPhone, items, shippingAddress, userId } = req.body;
    
    // Validate required fields
    if (!amount || !upiId) {
      return res.status(400).json({ 
        success: false, 
        error: "Amount and UPI ID are required" 
      });
    }

    // Validate UPI ID format (basic validation)
    const upiRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z]{3,}$/;
    if (!upiRegex.test(upiId)) {
      return res.status(400).json({ 
        success: false, 
        error: "Invalid UPI ID format. Use format: username@bankname" 
      });
    }

    // Validate amount
    if (amount <= 0 || amount > 100000) {
      return res.status(400).json({ 
        success: false, 
        error: "Invalid amount. Must be between ₹1 and ₹1,00,000" 
      });
    }

    // Simulate UPI payment processing
    console.log(`Processing UPI payment: ₹${amount} to ${upiId}`);
    
    // Simulate payment processing delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Generate unique payment ID
    const paymentId = `UPI_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    // Simulate payment success (90% success rate)
    const isSuccess = Math.random() > 0.1;
    
    if (isSuccess) {
      // Create order for successful UPI payment
      const orderId = `ORD-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
      
      const order = new Order({
        orderId,
        userId: userId,
        items: items,
        totalAmount: amount,
        shippingAddress: shippingAddress,
        paymentMethod: 'UPI',
        paymentStatus: 'completed',
        orderStatus: 'placed',
        trackingNumber: `TRK-${Date.now()}`,
        statusHistory: [{
          status: 'placed',
          note: 'Order has been placed successfully via UPI'
        }],
        estimatedDelivery: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)
      });
      
      await order.save();
      
      // Clear user's cart after successful order
      if (userId) {
        await Users.findByIdAndUpdate(userId, {
          cartData: {}
        });
      }
      
      // Payment successful
      const paymentData = {
        success: true,
        paymentId,
        transactionId: `TXN_${Date.now()}`,
        amount,
        upiId,
        customerName: customerName || 'Customer',
        customerPhone: customerPhone || 'N/A',
        status: 'SUCCESS',
        message: 'UPI payment processed successfully',
        timestamp: new Date().toISOString(),
        bankReference: `BANK_REF_${Math.random().toString(36).substr(2, 8)}`,
        merchantId: 'SWAGSY_001',
        paymentMethod: 'UPI',
        order: order
      };
      
      console.log('UPI Payment successful:', paymentData);
      
      res.json(paymentData);
    } else {
      // Payment failed
      const errorData = {
        success: false,
        error: 'UPI payment failed',
        reason: 'Insufficient balance or transaction declined by bank',
        upiId,
        amount,
        timestamp: new Date().toISOString(),
        retryAfter: '5 minutes'
      };
      
      console.log('UPI Payment failed:', errorData);
      
      res.status(400).json(errorData);
    }
    
  } catch (err) {
    console.error("UPI payment error:", err);
    res.status(500).json({ 
      success: false, 
      error: "UPI payment processing failed",
      details: err.message 
    });
  }
});

// Cash on Delivery
app.post("/api/payment/cod", async (req, res) => {
  try {
    const { amount, address, items, userId } = req.body;
    
    // Generate order ID for COD
    const orderId = `ORD-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
    
    // Create order for COD
    const order = new Order({
      orderId,
      userId: userId,
      items: items,
      totalAmount: amount,
      shippingAddress: address,
      paymentMethod: 'Cash on Delivery',
      paymentStatus: 'pending',
      orderStatus: 'placed',
      trackingNumber: `TRK-${Date.now()}`,
      statusHistory: [{
        status: 'placed',
        note: 'Order has been placed successfully via Cash on Delivery'
      }],
      estimatedDelivery: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)
    });
    
    await order.save();
    
    // Clear user's cart after successful order
    if (userId) {
      await Users.findByIdAndUpdate(userId, {
        cartData: {}
      });
    }
    
    res.json({ 
      success: true, 
      orderId,
      message: "Cash on Delivery order placed successfully",
      amount,
      address,
      paymentMethod: "Cash on Delivery",
      order: order
    });
    
  } catch (err) {
    console.error("COD order error:", err);
    res.status(500).json({ success: false, error: "Failed to place COD order" });
  }
});

// Create order
app.post('/create-order', fetchUser, async (req, res) => {
  try {
    const { items, shippingAddress, paymentMethod, totalAmount } = req.body;
    
    // Generate unique order ID
    const orderId = `ORD-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
    
    // Create order
    const order = new Order({
      orderId,
      userId: req.user.id,
      items,
      totalAmount,
      shippingAddress,
      paymentMethod,
      paymentStatus: 'pending',
      orderStatus: 'placed',
      trackingNumber: `TRK-${Date.now()}`,
      statusHistory: [{
        status: 'placed',
        note: 'Order has been placed successfully'
      }],
      estimatedDelivery: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) // 7 days from now
    });
    
    await order.save();
    
    // Clear user's cart after successful order
    await Users.findByIdAndUpdate(req.user.id, {
      cartData: {}
    });
    
    res.json({ 
      success: true, 
      order: order,
      message: "Order created successfully" 
    });
  } catch (err) {
    console.error("Create order error:", err);
    res.status(500).json({ success: false, error: "Failed to create order" });
  }
});

// Get user orders
app.get('/orders', fetchUser, async (req, res) => {
  try {
    const orders = await Order.find({ userId: req.user.id })
      .sort({ orderDate: -1 });
    
    res.json({ success: true, orders });
  } catch (err) {
    console.error("Get orders error:", err);
    res.status(500).json({ success: false, error: "Failed to fetch orders" });
  }
});

// Get specific order details
app.get('/orders/:orderId', fetchUser, async (req, res) => {
  try {
    const order = await Order.findOne({ 
      orderId: req.params.orderId, 
      userId: req.user.id 
    });
    
    if (!order) {
      return res.status(404).json({ success: false, error: "Order not found" });
    }
    
    res.json({ success: true, order });
  } catch (err) {
    console.error("Get order error:", err);
    res.status(500).json({ success: false, error: "Failed to fetch order" });
  }
});

// Update order status (Admin only)
app.put('/orders/:orderId/status', fetchUser, async (req, res) => {
  try {
    const { status, note } = req.body;
    const order = await Order.findOne({ orderId: req.params.orderId });
    
    if (!order) {
      return res.status(404).json({ success: false, error: "Order not found" });
    }
    
    // Add status to history
    order.statusHistory.push({
      status,
      note: note || `Order status updated to ${status}`
    });
    
    order.orderStatus = status;
    
    // Set delivery date if status is delivered
    if (status === 'delivered') {
      order.actualDelivery = new Date();
    }
    
    await order.save();
    
    res.json({ 
      success: true, 
      order,
      message: "Order status updated successfully" 
    });
  } catch (err) {
    console.error("Update order status error:", err);
    res.status(500).json({ success: false, error: "Failed to update order status" });
  }
});

// Admin: Get all users
app.get('/api/users', async (req, res) => {
  try {
    const users = await Users.find({}, { name: 1, email: 1, _id: 0 });
    res.json(users);
  } catch (err) {
    console.error("Admin user fetch error:", err);
    res.status(500).send("Server error");
  }
});

// Admin: Get all orders
app.get('/api/orders', async (req, res) => {
  try {
    const orders = await Order.find({}).sort({ orderDate: -1 });
    res.json({ success: true, orders });
  } catch (err) {
    console.error("Admin orders fetch error:", err);
    res.status(500).json({ success: false, error: "Failed to fetch orders" });
  }
});

// Start server
app.listen(port, (err) => {
  if (!err) console.log("\u2705 Server Running on Port " + port);
  else console.error("\u274C Server Error:", err);
});
