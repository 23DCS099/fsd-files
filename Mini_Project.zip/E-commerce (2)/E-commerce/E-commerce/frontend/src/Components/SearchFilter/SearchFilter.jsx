import React, { useState, useEffect } from 'react';
import './SearchFilter.css';

export const SearchFilter = ({ onSearch, onFilter, products, category }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [priceRange, setPriceRange] = useState({ min: '', max: '' });
  const [selectedBrands, setSelectedBrands] = useState([]);
  const [selectedClothTypes, setSelectedClothTypes] = useState([]);
  const [selectedSizes, setSelectedSizes] = useState([]);
  const [showFilters, setShowFilters] = useState(false);

  // Extract unique values for filters
  const brands = [...new Set(products.map(p => p.brand).filter(Boolean))];
  const clothTypes = [...new Set(products.map(p => p.clothType).filter(Boolean))];
  const sizes = [...new Set(products.flatMap(p => p.sizes || []))];

  useEffect(() => {
    // Debounced search
    const timeoutId = setTimeout(() => {
      if (searchTerm.trim()) {
        onSearch(searchTerm);
      }
    }, 300);

    return () => clearTimeout(timeoutId);
  }, [searchTerm, onSearch]);

  const handleFilter = () => {
    const filters = {
      priceRange,
      brands: selectedBrands,
      clothTypes: selectedClothTypes,
      sizes: selectedSizes
    };
    onFilter(filters);
  };

  const clearFilters = () => {
    setPriceRange({ min: '', max: '' });
    setSelectedBrands([]);
    setSelectedClothTypes([]);
    setSelectedSizes([]);
    onFilter({});
  };

  const toggleBrand = (brand) => {
    setSelectedBrands(prev => 
      prev.includes(brand) 
        ? prev.filter(b => b !== brand)
        : [...prev, brand]
    );
  };

  const toggleClothType = (type) => {
    setSelectedClothTypes(prev => 
      prev.includes(type) 
        ? prev.filter(t => t !== type)
        : [...prev, type]
    );
  };

  const toggleSize = (size) => {
    setSelectedSizes(prev => 
      prev.includes(size) 
        ? prev.filter(s => s !== size)
        : [...prev, size]
    );
  };

  return (
    <div className="search-filter-container">
      {/* Search Bar */}
      <div className="search-section">
        <div className="search-input-container">
          <input
            type="text"
            placeholder={`Search ${category} products...`}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="search-input"
          />
          <button className="search-btn">
            🔍
          </button>
        </div>
        
        <button 
          className="filter-toggle-btn"
          onClick={() => setShowFilters(!showFilters)}
        >
          {showFilters ? 'Hide Filters' : 'Show Filters'} ⚙️
        </button>
      </div>

      {/* Filters Panel */}
      {showFilters && (
        <div className="filters-panel">
          <div className="filter-group">
            <h4>Price Range</h4>
            <div className="price-inputs">
              <input
                type="number"
                placeholder="Min"
                value={priceRange.min}
                onChange={(e) => setPriceRange(prev => ({ ...prev, min: e.target.value }))}
                className="price-input"
              />
              <span>-</span>
              <input
                type="number"
                placeholder="Max"
                value={priceRange.max}
                onChange={(e) => setPriceRange(prev => ({ ...prev, max: e.target.value }))}
                className="price-input"
              />
            </div>
          </div>

          <div className="filter-group">
            <h4>Brands</h4>
            <div className="filter-options">
              {brands.map(brand => (
                <label key={brand} className="filter-option">
                  <input
                    type="checkbox"
                    checked={selectedBrands.includes(brand)}
                    onChange={() => toggleBrand(brand)}
                  />
                  <span>{brand}</span>
                </label>
              ))}
            </div>
          </div>

          <div className="filter-group">
            <h4>Cloth Type</h4>
            <div className="filter-options">
              {clothTypes.map(type => (
                <label key={type} className="filter-option">
                  <input
                    type="checkbox"
                    checked={selectedClothTypes.includes(type)}
                    onChange={() => toggleClothType(type)}
                  />
                  <span>{type}</span>
                </label>
              ))}
            </div>
          </div>

          <div className="filter-group">
            <h4>Available Sizes</h4>
            <div className="filter-options">
              {sizes.map(size => (
                <label key={size} className="filter-option">
                  <input
                    type="checkbox"
                    checked={selectedSizes.includes(size)}
                    onChange={() => toggleSize(size)}
                  />
                  <span>{size}</span>
                </label>
              ))}
            </div>
          </div>

          <div className="filter-actions">
            <button onClick={handleFilter} className="apply-filters-btn">
              Apply Filters
            </button>
            <button onClick={clearFilters} className="clear-filters-btn">
              Clear All
            </button>
          </div>
        </div>
      )}
    </div>
  );
}; 