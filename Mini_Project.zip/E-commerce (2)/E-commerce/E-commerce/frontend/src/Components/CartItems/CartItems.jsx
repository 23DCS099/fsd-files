// cartitems.jsx (Multiple Payment Methods Integration)
import React, { useContext, useState, useEffect } from 'react';
import './CartItems.css';
import { ShopContext } from '../../Context/ShopContext';
import remove_icon from '../Assets/cart_cross_icon.png';

export const CartItems = () => {
  const { all_product, cartItems, removeFromCart, getTotalCartAmount } = useContext(ShopContext);
  const [paymentMethod, setPaymentMethod] = useState('card');
  const [showPaymentOptions, setShowPaymentOptions] = useState(false);
  const [upiId, setUpiId] = useState('');
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [savedAddresses, setSavedAddresses] = useState([]);
  const [selectedAddress, setSelectedAddress] = useState('');
  const [showAddressForm, setShowAddressForm] = useState(false);
  const [newAddress, setNewAddress] = useState({
    name: '',
    phone: '',
    address: '',
    city: '',
    state: '',
    pincode: ''
  });

  // Load saved addresses from localStorage
  useEffect(() => {
    const saved = JSON.parse(localStorage.getItem('saved-addresses') || '[]');
    setSavedAddresses(saved);
    if (saved.length > 0) {
      setSelectedAddress(saved[0].id);
    }
  }, []);

  const saveNewAddress = () => {
    if (!newAddress.name || !newAddress.phone || !newAddress.address || !newAddress.city || !newAddress.state || !newAddress.pincode) {
      alert('Please fill all address fields');
      return;
    }

    const addressToSave = {
      id: Date.now().toString(),
      ...newAddress,
      isDefault: savedAddresses.length === 0
    };

    const updatedAddresses = [...savedAddresses, addressToSave];
    setSavedAddresses(updatedAddresses);
    localStorage.setItem('saved-addresses', JSON.stringify(updatedAddresses));
    
    setSelectedAddress(addressToSave.id);
    setShowAddressForm(false);
    setNewAddress({ name: '', phone: '', address: '', city: '', state: '', pincode: '' });
    
    alert('Address saved successfully!');
  };

  const getSelectedAddressText = () => {
    const address = savedAddresses.find(addr => addr.id === selectedAddress);
    if (address) {
      return `${address.name}, ${address.phone}, ${address.address}, ${address.city}, ${address.state} - ${address.pincode}`;
    }
    return '';
  };

  const makePayment = async () => {
    const amount = getTotalCartAmount();
    
    if (paymentMethod === 'cod' && !selectedAddress) {
      alert('Please select or add a delivery address for Cash on Delivery');
      return;
    }
    
    if (paymentMethod === 'upi' && (!upiId.trim() || !customerName.trim() || !customerPhone.trim())) {
      alert('Please enter UPI ID, Customer Name, and Phone Number');
      return;
    }

    setIsProcessing(true);

    try {
      let response;
      
      switch (paymentMethod) {
        case 'card':
          response = await fetch("http://localhost:4000/api/payment/create-checkout-session", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({ amount }),
          });
          
          const data = await response.json();
          if (data.url) {
            window.location.href = data.url; // Redirect to Stripe Checkout
          }
          break;

        case 'upi':
          response = await fetch("http://localhost:4000/api/payment/upi", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({ amount, upiId, customerName, customerPhone }),
          });
          
          const upiData = await response.json();
          if (upiData.success) {
            alert(`UPI Payment Successful! Payment ID: ${upiData.paymentId}`);
            // Redirect to success page or clear cart
            window.location.href = '/payment-done';
          }
          break;

        case 'cod':
          response = await fetch("http://localhost:4000/api/payment/cod", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({ amount, address: selectedAddress }),
          });
          
          const codData = await response.json();
          if (codData.success) {
            alert(`Cash on Delivery Order Placed! Order ID: ${codData.orderId}`);
            // Redirect to success page or clear cart
            window.location.href = '/payment-done';
          }
          break;

        default:
          alert('Please select a payment method');
      }
    } catch (error) {
      console.error("Payment error:", error);
      alert("Payment failed. Please try again.");
    } finally {
      setIsProcessing(false);
    }
  };

  const handlePaymentMethodChange = (method) => {
    setPaymentMethod(method);
    setShowPaymentOptions(false);
  };

  return (
    <div className='cartitems'>
      <div className="cartitems-format-main">
        <p>Products</p>
        <p>Title</p>
        <p>Price</p>
        <p>Quantity</p>
        <p>Total</p>
        <p>Remove</p>
      </div>
      <hr />
      {all_product.map((e) => {
        if (cartItems[e.id] > 0) {
          return (
            <div key={e.id}>
              <div className="cartitems-format cartitems-format-main">
                <img src={e.image} alt="" className="carticon-product-icon" />
                <p>{e.name}</p>
                <p>₹{e.new_price}</p>
                <button className="cartitems-quantity">{cartItems[e.id]}</button>
                <p>₹{e.new_price * cartItems[e.id]}</p>
                <img
                  className='cartitems-remove-icon'
                  src={remove_icon}
                  onClick={() => removeFromCart(e.id)}
                  alt="Remove"
                />
              </div>
              <hr />
            </div>
          );
        } else {
          return null;
        }
      })}
      <div className="cartitems-down">
        <div className="cartitems-total">
          <h1>Cart Totals</h1>
          <div>
            <div className="cartitems-total-item">
              <p>Subtotal</p>
              <p>₹{getTotalCartAmount()}</p>
            </div>
            <hr />
            <div className="cartitems-total-item">
              <p>Shipping Fee</p>
              <p>Free</p>
            </div>
            <hr />
            <div className="cartitems-total-item">
              <h3>Total</h3>
              <h3>₹{getTotalCartAmount()}</h3>
            </div>
          </div>

          {/* Payment Method Selection */}
          <div className="payment-method-section">
            <h3>Select Payment Method</h3>
            <div className="payment-methods">
              <div 
                className={`payment-method ${paymentMethod === 'card' ? 'active' : ''}`}
                onClick={() => handlePaymentMethodChange('card')}
              >
                <input 
                  type="radio" 
                  name="payment" 
                  value="card" 
                  checked={paymentMethod === 'card'}
                  onChange={() => handlePaymentMethodChange('card')}
                />
                <label>Credit/Debit Card</label>
              </div>
              
              <div 
                className={`payment-method ${paymentMethod === 'upi' ? 'active' : ''}`}
                onClick={() => handlePaymentMethodChange('upi')}
              >
                <input 
                  type="radio" 
                  name="payment" 
                  value="upi" 
                  checked={paymentMethod === 'upi'}
                  onChange={() => handlePaymentMethodChange('upi')}
                />
                <label>UPI Payment</label>
              </div>
              
              <div 
                className={`payment-method ${paymentMethod === 'cod' ? 'active' : ''}`}
                onClick={() => handlePaymentMethodChange('cod')}
              >
                <input 
                  type="radio" 
                  name="payment" 
                  value="cod" 
                  checked={paymentMethod === 'cod'}
                  onChange={() => handlePaymentMethodChange('cod')}
                />
                <label>Cash on Delivery</label>
              </div>
            </div>

            {/* UPI ID Input */}
            {paymentMethod === 'upi' && (
              <div className="payment-input">
                <label>UPI ID:</label>
                <input
                  type="text"
                  placeholder="Enter UPI ID (e.g., user@upi)"
                  value={upiId}
                  onChange={(e) => setUpiId(e.target.value)}
                />
                <label>Customer Name:</label>
                <input
                  type="text"
                  placeholder="Enter your full name"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                />
                <label>Phone Number:</label>
                <input
                  type="tel"
                  placeholder="Enter your phone number"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                />
              </div>
            )}

            {/* Delivery Address Input for COD */}
            {paymentMethod === 'cod' && (
              <div className="payment-input">
                <label>Delivery Address:</label>
                
                {savedAddresses.length > 0 && (
                  <div className="saved-addresses">
                    <h4>Saved Addresses:</h4>
                    {savedAddresses.map(address => (
                      <div 
                        key={address.id}
                        className={`address-option ${selectedAddress === address.id ? 'selected' : ''}`}
                        onClick={() => setSelectedAddress(address.id)}
                      >
                        <input
                          type="radio"
                          name="selectedAddress"
                          checked={selectedAddress === address.id}
                          onChange={() => setSelectedAddress(address.id)}
                        />
                        <div className="address-details">
                          <strong>{address.name}</strong> - {address.phone}
                          <div>{address.address}, {address.city}, {address.state} - {address.pincode}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {selectedAddress && (
                  <div className="selected-address-display">
                    <strong>Selected Address:</strong>
                    <p>{getSelectedAddressText()}</p>
                  </div>
                )}

                <div className="address-actions">
                  <button 
                    type="button"
                    className="add-new-address-btn"
                    onClick={() => setShowAddressForm(!showAddressForm)}
                  >
                    {showAddressForm ? 'Cancel' : 'Add New Address'}
                  </button>
                </div>

                {showAddressForm && (
                  <div className="new-address-form">
                    <h4>Add New Address:</h4>
                    <input
                      type="text"
                      placeholder="Full Name"
                      value={newAddress.name}
                      onChange={(e) => setNewAddress(prev => ({ ...prev, name: e.target.value }))}
                    />
                    <input
                      type="tel"
                      placeholder="Phone Number"
                      value={newAddress.phone}
                      onChange={(e) => setNewAddress(prev => ({ ...prev, phone: e.target.value }))}
                    />
                    <textarea
                      placeholder="Full Address"
                      value={newAddress.address}
                      onChange={(e) => setNewAddress(prev => ({ ...prev, address: e.target.value }))}
                      rows="3"
                    />
                    <input
                      type="text"
                      placeholder="City"
                      value={newAddress.city}
                      onChange={(e) => setNewAddress(prev => ({ ...prev, city: e.target.value }))}
                    />
                    <input
                      type="text"
                      placeholder="State"
                      value={newAddress.state}
                      onChange={(e) => setNewAddress(prev => ({ ...prev, state: e.target.value }))}
                    />
                    <input
                      type="text"
                      placeholder="Pincode"
                      value={newAddress.pincode}
                      onChange={(e) => setNewAddress(prev => ({ ...prev, pincode: e.target.value }))}
                    />
                    <button 
                      type="button"
                      className="save-address-btn"
                      onClick={saveNewAddress}
                    >
                      Save Address
                    </button>
                  </div>
                )}

                {!selectedAddress && savedAddresses.length === 0 && (
                  <div className="no-address-message">
                    <p>No saved addresses. Please add a delivery address.</p>
                  </div>
                )}
              </div>
            )}
          </div>

          <button 
            onClick={makePayment} 
            className="checkout-btn"
            disabled={isProcessing}
          >
            {isProcessing ? 'Processing...' : 'PROCEED TO CHECKOUT'}
          </button>
        </div>
        <div className="cartitems-promocode">
          <p>If you have a promo code, Enter it here</p>
          <div className="cartitems-promobox">
            <input type="text" placeholder='promo code' />
            <button>Submit</button>
          </div>
        </div>
      </div>
    </div>
  );
};
