
import React, { useContext, useState } from 'react';
import './ProductDisplay.css';
import star_icon from "../Assets/star_icon.png";
import star_dull_icon from "../Assets/star_dull_icon.png";
import { ShopContext } from '../../Context/ShopContext';

export const ProductDisplay = (props) => {
  const { product, description, sizes, clothType, brand } = props;
  const { addToCart } = useContext(ShopContext);
  const [selectedSize, setSelectedSize] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [showDescription, setShowDescription] = useState(false);
  const [isAddingToCart, setIsAddingToCart] = useState(false);

  if (!product) return <div>Loading...</div>;

  const handleAddToCart = async () => {
    if (!selectedSize) {
      alert('Please select a size before adding to cart');
      return;
    }
    
    setIsAddingToCart(true);
    
    try {
      // Add the product to cart with the selected quantity and size
      await addToCart(product.id, quantity, selectedSize);
      alert(`Added ${quantity} ${product.name} (Size: ${selectedSize}) to cart!`);
    } catch (error) {
      console.error('Error adding to cart:', error);
      alert('Failed to add item to cart. Please try again.');
    } finally {
      setIsAddingToCart(false);
    }
  };

  const handleBuyNow = async () => {
    if (!selectedSize) {
      alert('Please select a size before buying');
      return;
    }
    
    setIsAddingToCart(true);
    
    try {
      // Add to cart first
      await addToCart(product.id, quantity, selectedSize);
      alert(`Added ${quantity} ${product.name} (Size: ${selectedSize}) to cart! Redirecting to checkout...`);
      // Redirect to cart page
      window.location.href = '/cart';
    } catch (error) {
      console.error('Error adding to cart:', error);
      alert('Failed to add item to cart. Please try again.');
    } finally {
      setIsAddingToCart(false);
    }
  };

  const handleSizeSelect = (size) => {
    setSelectedSize(size);
  };

  const handleQuantityChange = (change) => {
    const newQuantity = quantity + change;
    if (newQuantity >= 1 && newQuantity <= 10) {
      setQuantity(newQuantity);
    }
  };

  // Use actual product data or fallback to defaults
  const productSizes = sizes && sizes.length > 0 ? sizes : ['S', 'M', 'L', 'XL', 'XXL'];
  const productDescription = description || "Premium quality clothing designed for comfort and style. This fashionable piece features modern design elements perfect for everyday wear.";
  const productBrand = brand || "Swagsy";
  const productClothType = clothType || "clothing";

  // Debug logging
  console.log('ProductDisplay - Product:', product);
  console.log('ProductDisplay - Sizes:', sizes);
  console.log('ProductDisplay - ProductSizes:', productSizes);

  return (
    <div className='productdisplay'>
      <div className="productdisplay-left">
        <div className="productdisplay-img-list">
          {[...Array(4)].map((_, i) => (
            <img key={i} src={product.image} alt="product" />
          ))}
        </div>
        <div className="prodductdisplay-img">
          <img className='productdisplay-main-img' src={product.image} alt="product" />
        </div>
      </div>
      <div className="productdisplay-right">
        <div className="product-header">
          <h1>{product.name}</h1>
          {productBrand && <span className="product-brand">by {productBrand}</span>}
        </div>
        
        <div className="productdisplay-right-star">
          {[...Array(4)].map((_, i) => <img key={i} src={star_icon} alt="star" />)}
          <img src={star_dull_icon} alt="star" />
          <p>(122)</p>
        </div>
        
        <div className="productdisplay-right-prices">
          <div className="productdisplay-right-price-old">₹{product.old_price}</div>
          <div className="productdisplay-right-price-new">₹{product.new_price}</div>
          {product.old_price > product.new_price && (
            <div className="discount-badge">
              {Math.round(((product.old_price - product.new_price) / product.old_price) * 100)}% OFF
            </div>
          )}
        </div>
        
        <div className="productdisplay-right-description-toggle">
          <button 
            className="description-toggle-btn"
            onClick={() => setShowDescription(!showDescription)}
          >
            {showDescription ? 'Hide Description' : 'Show Description'}
          </button>
          {showDescription && (
            <div className="product-description-content">
              {productDescription}
            </div>
          )}
        </div>
        
        <div className="productdisplay-right-size">
          <h3>Select Size <span className="required">*</span></h3>
          <div className="productdisplay-right-sizes">
            {productSizes && productSizes.length > 0 ? (
              productSizes.map(size => (
                <div 
                  key={size} 
                  className={`size-option ${selectedSize === size ? 'selected' : ''}`}
                  onClick={() => handleSizeSelect(size)}
                >
                  {size}
                </div>
              ))
            ) : (
              <div className="no-sizes-available">
                <p>No sizes available for this product</p>
              </div>
            )}
          </div>
          {selectedSize && (
            <p className="size-selected">Size selected: <strong>{selectedSize}</strong></p>
          )}
          {!selectedSize && productSizes && productSizes.length > 0 && (
            <p className="size-required">Please select a size to continue</p>
          )}
        </div>

        <div className="productdisplay-right-quantity">
          <h3>Quantity</h3>
          <div className="quantity-selector">
            <button 
              className="quantity-btn"
              onClick={() => handleQuantityChange(-1)}
              disabled={quantity <= 1}
            >
              -
            </button>
            <span className="quantity-display">{quantity}</span>
            <button 
              className="quantity-btn"
              onClick={() => handleQuantityChange(1)}
              disabled={quantity >= 10}
            >
              +
            </button>
          </div>
        </div>

        <div className="product-actions">
          <button 
            className="add-to-cart-btn"
            onClick={handleAddToCart}
            disabled={!selectedSize || isAddingToCart}
          >
            {isAddingToCart ? 'ADDING...' : (selectedSize ? 'ADD TO CART' : 'SELECT SIZE FIRST')}
          </button>
          
          <button 
            className="buy-now-btn"
            onClick={handleBuyNow}
            disabled={!selectedSize || isAddingToCart}
          >
            {isAddingToCart ? 'PROCESSING...' : (selectedSize ? 'BUY NOW' : 'SELECT SIZE FIRST')}
          </button>
        </div>

        <div className="product-info">
          <p className='productdisplay-right-category'>
            <span>Category:</span> {product.category}, {productClothType}
          </p>
          <p className='productdisplay-right-category'>
            <span>Brand:</span> {productBrand}
          </p>
          <p className='productdisplay-right-category'>
            <span>Available Sizes:</span> {productSizes.join(', ')}
          </p>
        </div>
      </div>
    </div>
  );
};
