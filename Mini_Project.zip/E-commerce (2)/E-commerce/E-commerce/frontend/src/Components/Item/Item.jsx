import React, { useState } from 'react'
import './Item.css'
import { Link } from 'react-router-dom';

export const Item = (props) => {
  // Default description if not provided
  const description = props.description || "Premium quality clothing designed for comfort and style. This fashionable piece features modern design elements perfect for everyday wear.";
  const [showDescription, setShowDescription] = useState(false);

  const sizes = props.sizes || ['S', 'M', 'L', 'XL', 'XXL'];
  const [selectedSize, setSelectedSize] = useState('');

  return (
    <div className='item'>
      <div className="item-image-container">
        <Link to={`/product/${props.id}`}>
          <img 
            src={props.image} 
            alt={props.name}
            className="item-image"
            onClick={() => window.scrollTo(0, 0)}
          />
        </Link>
      </div>

      <p className="item-name">{props.name}</p>
      
      {/* Show Description Button */}
      <button 
        className="show-description-btn"
        onClick={() => setShowDescription(!showDescription)}
      >
        {showDescription ? 'Hide Description' : 'Show Description'}
      </button>
      
      {/* Description Display - Only visible when showDescription is true */}
      {showDescription && (
        <div className="item-description">
          <p>{description}</p>
        </div>
      )}
      
      <div className="item-prices">
        <div className="item-price-new">
           ₹{props.new_price}
        </div>
        <div className="item-price-old">
            ₹{props.old_price}
        </div>
      </div>
    </div>
  )
}

