import React, { createContext, useEffect, useState } from "react";

export const ShopContext = createContext(null);

// Default empty cart object
const getDefaultCart = () => {
  let cart = {};
  for (let index = 0; index <= 300; index++) {
    cart[index] = 0;
  }
  return cart;
};

const ShopContextProvider = (props) => {
  const [all_product, setAll_Product] = useState([]);
  const [cartItems, setCartItems] = useState(getDefaultCart());
  const [isLoading, setIsLoading] = useState(true);

  // Fetch all products + user cart (if logged in)
  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch products
        const productsResponse = await fetch("http://localhost:4000/allproducts");
        const productsData = await productsResponse.json();
        setAll_Product(productsData);

        // Fetch user cart if logged in
        const token = localStorage.getItem("auth-token");
        if (token) {
          try {
            const cartResponse = await fetch("http://localhost:4000/getcart", {
              method: "POST",
              headers: {
                Accept: "application/json",
                "auth-token": token,
                "Content-Type": "application/json",
              },
              body: JSON.stringify({}),
            });
            
            const cartData = await cartResponse.json();
            if (cartData.success) {
              setCartItems(cartData.cart);
            }
          } catch (err) {
            console.error("Cart fetch error:", err);
            // Keep existing cart items if fetch fails
          }
        }
      } catch (error) {
        console.error("Products fetch error:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, []);

  // Add product to cart with improved error handling and support for size/quantity
  const addToCart = async (itemId, quantity = 1, size = null) => {
    const token = localStorage.getItem("auth-token");
    
    if (token) {
      try {
        const response = await fetch("http://localhost:4000/addtocart", {
          method: "POST",
          headers: {
            Accept: "application/json",
            "auth-token": token,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ 
            itemId, 
            quantity: quantity || 1, 
            size: size || null 
          }),
        });

        const data = await response.json();
        if (data.success) {
          // Update local cart state immediately
          setCartItems(prev => ({
            ...prev,
            [itemId]: (prev[itemId] || 0) + (quantity || 1),
          }));

          // Refetch updated cart from backend to ensure sync
          try {
            const updatedCartResponse = await fetch("http://localhost:4000/getcart", {
              method: "POST",
              headers: {
                Accept: "application/json",
                "auth-token": token,
                "Content-Type": "application/json",
              },
              body: JSON.stringify({}),
            });
            
            const updatedCartData = await updatedCartResponse.json();
            if (updatedCartData.success) {
              setCartItems(updatedCartData.cart);
            }
          } catch (err) {
            console.error("Cart sync error:", err);
          }
        } else {
          console.error("Failed to add to cart:", data);
          throw new Error(data.message || "Failed to add to cart");
        }
      } catch (error) {
        console.error("Add to cart error:", error);
        throw error; // Re-throw to let the component handle it
      }
    } else {
      // Fallback for guests - store in localStorage
      const guestCart = JSON.parse(localStorage.getItem("guest-cart") || "{}");
      guestCart[itemId] = (guestCart[itemId] || 0) + (quantity || 1);
      localStorage.setItem("guest-cart", JSON.stringify(guestCart));
      
      setCartItems(prev => ({
        ...prev,
        [itemId]: (prev[itemId] || 0) + (quantity || 1),
      }));
    }
  };

  // Remove product from cart with improved error handling
  const removeFromCart = async (itemId) => {
    const token = localStorage.getItem("auth-token");
    
    // Update local state immediately for better UX
    setCartItems(prev => ({
      ...prev,
      [itemId]: Math.max((prev[itemId] || 1) - 1, 0),
    }));

    if (token) {
      try {
        const response = await fetch("http://localhost:4000/removefromcart", {
          method: "POST",
          headers: {
            Accept: "application/json",
            "auth-token": token,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ itemId }),
        });

        if (response.ok) {
          // Refetch updated cart to ensure sync
          try {
            const updatedCartResponse = await fetch("http://localhost:4000/getcart", {
              method: "POST",
              headers: {
                Accept: "application/json",
                "auth-token": token,
                "Content-Type": "application/json",
              },
              body: JSON.stringify({}),
            });
            
            const updatedCartData = await updatedCartResponse.json();
            if (updatedCartData.success) {
              setCartItems(updatedCartData.cart);
            }
          } catch (err) {
            console.error("Cart sync error:", err);
          }
        }
      } catch (err) {
        console.error("Remove from cart error:", err);
        // Revert local state if backend call fails
        setCartItems(prev => ({
          ...prev,
          [itemId]: (prev[itemId] || 0) + 1,
        }));
      }
    } else {
      // Update guest cart in localStorage
      const guestCart = JSON.parse(localStorage.getItem("guest-cart") || "{}");
      if (guestCart[itemId] > 0) {
        guestCart[itemId] -= 1;
        if (guestCart[itemId] === 0) {
          delete guestCart[itemId];
        }
        localStorage.setItem("guest-cart", JSON.stringify(guestCart));
      }
    }
  };

  // Clear cart (useful for logout)
  const clearCart = () => {
    setCartItems(getDefaultCart());
    localStorage.removeItem("guest-cart");
  };

  // Calculate total amount
  const getTotalCartAmount = () => {
    let totalAmount = 0;
    for (const item in cartItems) {
      if (cartItems[item] > 0) {
        const itemInfo = all_product.find(
          (product) => product.id === Number(item)
        );
        if (itemInfo) {
          totalAmount += itemInfo.new_price * cartItems[item];
        }
      }
    }
    return totalAmount;
  };

  // Total quantity of items in cart
  const getTotalCartItems = () => {
    let totalItem = 0;
    for (const item in cartItems) {
      if (cartItems[item] > 0) {
        totalItem += cartItems[item];
      }
    }
    return totalItem;
  };

  const contextValue = {
    getTotalCartItems,
    getTotalCartAmount,
    all_product,
    cartItems,
    addToCart,
    removeFromCart,
    clearCart,
    isLoading,
  };

  return (
    <ShopContext.Provider value={contextValue}>
      {props.children}
    </ShopContext.Provider>
  );
};

export default ShopContextProvider;
