import React from 'react'
import { CartItems } from '../Components/CartItems/CartItems'

export const Cart = () => {
  return (
    <div>
      <CartItems/>
    </div>
  )
}
