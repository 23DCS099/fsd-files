import React from 'react';

const PaymentDone = () => {
  return (
    <div style={{ textAlign: "center", padding: "100px" }}>
      <h1>Payment Successful!</h1>
      <p>Thank you for shopping with Swagsy.</p>
    </div>
  );
};

export default PaymentDone;
