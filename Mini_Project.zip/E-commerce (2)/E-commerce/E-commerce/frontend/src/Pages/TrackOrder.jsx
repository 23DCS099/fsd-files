import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import './CSS/TrackOrder.css';

export const TrackOrder = () => {
  const { orderId } = useParams();
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (orderId) {
      fetchOrderDetails();
    }
  }, [orderId]);

  const fetchOrderDetails = async () => {
    try {
      const token = localStorage.getItem('auth-token');
      if (!token) {
        setError('Please log in to track your order');
        setLoading(false);
        return;
      }

      const response = await fetch(`http://localhost:4000/orders/${orderId}`, {
        method: 'GET',
        headers: {
          'auth-token': token,
          'Content-Type': 'application/json'
        }
      });

      const data = await response.json();
      if (data.success) {
        setOrder(data.order);
      } else {
        setError(data.error || 'Order not found');
      }
    } catch (error) {
      console.error('Error fetching order:', error);
      setError('Error fetching order details. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'placed':
        return '#007bff';
      case 'confirmed':
        return '#17a2b8';
      case 'processing':
        return '#ffc107';
      case 'shipped':
        return '#fd7e14';
      case 'delivered':
        return '#28a745';
      case 'cancelled':
        return '#dc3545';
      default:
        return '#6c757d';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'placed':
        return '📋';
      case 'confirmed':
        return '✅';
      case 'processing':
        return '⚙️';
      case 'shipped':
        return '🚚';
      case 'delivered':
        return '📦';
      case 'cancelled':
        return '❌';
      default:
        return '❓';
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR'
    }).format(amount);
  };

  const getProgressPercentage = (status) => {
    switch (status) {
      case 'placed':
        return 20;
      case 'confirmed':
        return 40;
      case 'processing':
        return 60;
      case 'shipped':
        return 80;
      case 'delivered':
        return 100;
      case 'cancelled':
        return 0;
      default:
        return 0;
    }
  };

  if (loading) {
    return (
      <div className="track-loading">
        <div className="loading-spinner"></div>
        <p>Loading order details...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="track-error">
        <h2>Error</h2>
        <p>{error}</p>
        <button onClick={fetchOrderDetails} className="retry-btn">
          Try Again
        </button>
      </div>
    );
  }

  if (!order) {
    return (
      <div className="track-error">
        <h2>Order Not Found</h2>
        <p>The order you're looking for doesn't exist or you don't have permission to view it.</p>
      </div>
    );
  }

  return (
    <div className="track-container">
      <div className="track-header">
        <h1>Track Your Order</h1>
        <p>Order #{order.orderId}</p>
      </div>

      <div className="track-content">
        <div className="order-overview">
          <div className="overview-card">
            <h3>Order Overview</h3>
            <div className="overview-details">
              <div className="detail-row">
                <span>Order Date:</span>
                <span>{formatDate(order.orderDate)}</span>
              </div>
              <div className="detail-row">
                <span>Total Amount:</span>
                <span className="total-amount">{formatCurrency(order.totalAmount)}</span>
              </div>
              <div className="detail-row">
                <span>Payment Method:</span>
                <span>{order.paymentMethod}</span>
              </div>
              <div className="detail-row">
                <span>Tracking Number:</span>
                <span className="tracking-number">{order.trackingNumber}</span>
              </div>
              {order.estimatedDelivery && (
                <div className="detail-row">
                  <span>Estimated Delivery:</span>
                  <span>{formatDate(order.estimatedDelivery)}</span>
                </div>
              )}
            </div>
          </div>

          <div className="status-card">
            <h3>Current Status</h3>
            <div className="current-status">
              <div 
                className="status-badge"
                style={{ backgroundColor: getStatusColor(order.orderStatus) }}
              >
                {getStatusIcon(order.orderStatus)} {order.orderStatus.toUpperCase()}
              </div>
              <div className="progress-bar">
                <div 
                  className="progress-fill"
                  style={{ 
                    width: `${getProgressPercentage(order.orderStatus)}%`,
                    backgroundColor: getStatusColor(order.orderStatus)
                  }}
                ></div>
              </div>
              <p className="progress-text">
                {getProgressPercentage(order.orderStatus)}% Complete
              </p>
            </div>
          </div>
        </div>

        <div className="tracking-timeline">
          <h3>Order Timeline</h3>
          <div className="timeline">
            {order.statusHistory.map((status, index) => (
              <div key={index} className="timeline-item">
                <div className="timeline-marker">
                  <div 
                    className="marker-dot"
                    style={{ backgroundColor: getStatusColor(status.status) }}
                  >
                    {getStatusIcon(status.status)}
                  </div>
                  {index < order.statusHistory.length - 1 && (
                    <div className="timeline-line"></div>
                  )}
                </div>
                <div className="timeline-content">
                  <div className="timeline-header">
                    <h4>{status.status.charAt(0).toUpperCase() + status.status.slice(1)}</h4>
                    <span className="timeline-date">{formatDate(status.timestamp)}</span>
                  </div>
                  {status.note && (
                    <p className="timeline-note">{status.note}</p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="order-items">
          <h3>Order Items</h3>
          <div className="items-list">
            {order.items.map((item, index) => (
              <div key={index} className="track-item">
                <div className="item-image">
                  <img src={item.productImage} alt={item.productName} />
                </div>
                <div className="item-details">
                  <h4>{item.productName}</h4>
                  <p>Size: {item.size}</p>
                  <p>Quantity: {item.quantity}</p>
                  <p className="item-price">{formatCurrency(item.price)}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="shipping-info">
          <h3>Shipping Information</h3>
          <div className="shipping-details">
            <div className="address-section">
              <h4>Delivery Address</h4>
              <div className="address">
                <p>{order.shippingAddress.street}</p>
                <p>{order.shippingAddress.city}, {order.shippingAddress.state}</p>
                <p>{order.shippingAddress.zipCode}, {order.shippingAddress.country}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
