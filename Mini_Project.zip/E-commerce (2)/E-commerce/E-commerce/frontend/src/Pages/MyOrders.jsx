import React, { useState, useEffect } from 'react';
import './CSS/MyOrders.css';
import { Link } from 'react-router-dom';

export const MyOrders = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    try {
      const token = localStorage.getItem('auth-token');
      if (!token) {
        setError('Please log in to view your orders');
        setLoading(false);
        return;
      }

      const response = await fetch('http://localhost:4000/orders', {
        method: 'GET',
        headers: {
          'auth-token': token,
          'Content-Type': 'application/json'
        }
      });

      const data = await response.json();
      if (data.success) {
        setOrders(data.orders);
      } else {
        setError('Failed to fetch orders');
      }
    } catch (error) {
      console.error('Error fetching orders:', error);
      setError('Error fetching orders. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'placed':
        return '#007bff';
      case 'confirmed':
        return '#17a2b8';
      case 'processing':
        return '#ffc107';
      case 'shipped':
        return '#fd7e14';
      case 'delivered':
        return '#28a745';
      case 'cancelled':
        return '#dc3545';
      default:
        return '#6c757d';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'placed':
        return '📋';
      case 'confirmed':
        return '✅';
      case 'processing':
        return '⚙️';
      case 'shipped':
        return '🚚';
      case 'delivered':
        return '📦';
      case 'cancelled':
        return '❌';
      default:
        return '❓';
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR'
    }).format(amount);
  };

  if (loading) {
    return (
      <div className="orders-loading">
        <div className="loading-spinner"></div>
        <p>Loading your orders...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="orders-error">
        <h2>Error</h2>
        <p>{error}</p>
        <button onClick={fetchOrders} className="retry-btn">
          Try Again
        </button>
      </div>
    );
  }

  if (orders.length === 0) {
    return (
      <div className="orders-empty">
        <div className="empty-icon">📦</div>
        <h2>No Orders Yet</h2>
        <p>You haven't placed any orders yet. Start shopping to see your orders here!</p>
        <Link to="/" className="shop-now-btn">
          Start Shopping
        </Link>
      </div>
    );
  }

  return (
    <div className="orders-container">
      <div className="orders-header">
        <h1>My Orders</h1>
        <p>Track and manage your orders</p>
      </div>

      <div className="orders-list">
        {orders.map((order) => (
          <div key={order._id} className="order-card">
            <div className="order-header">
              <div className="order-info">
                <h3>Order #{order.orderId}</h3>
                <p className="order-date">Placed on {formatDate(order.orderDate)}</p>
              </div>
              <div className="order-status">
                <span 
                  className="status-badge"
                  style={{ backgroundColor: getStatusColor(order.orderStatus) }}
                >
                  {getStatusIcon(order.orderStatus)} {order.orderStatus.toUpperCase()}
                </span>
              </div>
            </div>

            <div className="order-items">
              <h4>Items ({order.items.length})</h4>
              <div className="items-list">
                {order.items.map((item, index) => (
                  <div key={index} className="order-item">
                    <div className="item-image">
                      <img src={item.productImage} alt={item.productName} />
                    </div>
                    <div className="item-details">
                      <h5>{item.productName}</h5>
                      <p>Size: {item.size}</p>
                      <p>Quantity: {item.quantity}</p>
                      <p className="item-price">{formatCurrency(item.price)}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="order-summary">
              <div className="summary-row">
                <span>Total Amount:</span>
                <span className="total-amount">{formatCurrency(order.totalAmount)}</span>
              </div>
              <div className="summary-row">
                <span>Payment Method:</span>
                <span>{order.paymentMethod}</span>
              </div>
              <div className="summary-row">
                <span>Payment Status:</span>
                <span className={`payment-status ${order.paymentStatus}`}>
                  {order.paymentStatus.toUpperCase()}
                </span>
              </div>
              {order.estimatedDelivery && (
                <div className="summary-row">
                  <span>Estimated Delivery:</span>
                  <span>{formatDate(order.estimatedDelivery)}</span>
                </div>
              )}
            </div>

            <div className="order-actions">
              <Link 
                to={`/track-order/${order.orderId}`}
                className="track-order-btn"
              >
                Track Order
              </Link>
              <Link 
                to={`/order-details/${order.orderId}`}
                className="view-details-btn"
              >
                View Details
              </Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
