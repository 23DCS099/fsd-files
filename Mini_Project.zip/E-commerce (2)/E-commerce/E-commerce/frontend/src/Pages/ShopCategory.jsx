import React, { useContext, useState, useMemo } from 'react';
import './CSS/ShopCategory.css';
import { ShopContext } from '../Context/ShopContext';
import dropdown_icon from '../Components/Assets/dropdown_icon.png';
import { Item } from '../Components/Item/Item';

export const ShopCategory = (props) => {
  const { all_product } = useContext(ShopContext);
  const [sortBy, setSortBy] = useState('default');
  const [showSortOptions, setShowSortOptions] = useState(false);
  const [selectedBrand, setSelectedBrand] = useState('');
  const [selectedClothType, setSelectedClothType] = useState('');
  const [selectedSize, setSelectedSize] = useState('');

    // Filter products by category
    const categoryProducts = useMemo(() => {
      let filtered = all_product?.filter(item => props.category === item.category) || [];
    
    // Apply brand filter
    if (selectedBrand) {
      filtered = filtered.filter(item => item.brand === selectedBrand);
    }
    
    // Apply cloth type filter
    if (selectedClothType) {
      filtered = filtered.filter(item => item.clothType === selectedClothType);
    }
    
    // Apply size filter
    if (selectedSize) {
      filtered = filtered.filter(item => item.sizes && item.sizes.includes(selectedSize));
    }
    
    return filtered;
  }, [all_product, props.category, selectedBrand, selectedClothType, selectedSize]);

  // Sort products based on selected option
  const sortedProducts = useMemo(() => {
    const products = [...categoryProducts];
    
    switch (sortBy) {
      case 'price-low-high':
        return products.sort((a, b) => a.new_price - b.new_price);
      case 'price-high-low':
        return products.sort((a, b) => b.new_price - a.new_price);
      case 'name-a-z':
        return products.sort((a, b) => a.name.localeCompare(b.name));
      case 'name-z-a':
        return products.sort((a, b) => b.name.localeCompare(a.name));
      case 'newest':
        return products.sort((a, b) => new Date(b.date) - new Date(a.date));
      case 'oldest':
        return products.sort((a, b) => new Date(a.date) - new Date(a.date));
      case 'brand-a-z':
        return products.sort((a, b) => (a.brand || '').localeCompare(b.brand || ''));
      case 'age-young':
        return products.sort((a, b) => (a.age || 0) - (b.age || 0));
      case 'age-old':
        return products.sort((a, b) => (b.age || 0) - (a.age || 0));
      default:
        return products;
    }
  }, [categoryProducts, sortBy]);

  const handleSortChange = (sortOption) => {
    setSortBy(sortOption);
    setShowSortOptions(false);
  };

  const handleFilterChange = (filterType, value) => {
    switch (filterType) {
      case 'brand':
        setSelectedBrand(value === selectedBrand ? '' : value);
        break;
      case 'clothType':
        setSelectedClothType(value === selectedClothType ? '' : value);
        break;
      case 'size':
        setSelectedSize(value === selectedSize ? '' : value);
        break;
      default:
        break;
    }
  };

  const clearAllFilters = () => {
    setSelectedBrand('');
    setSelectedClothType('');
    setSelectedSize('');
    setSortBy('default');
  };

  const getSortDisplayText = () => {
    switch (sortBy) {
      case 'price-low-high': return 'Price: Low to High';
      case 'price-high-low': return 'Price: High to Low';
      case 'name-a-z': return 'Name: A to Z';
      case 'name-z-a': return 'Name: Z to A';
      case 'newest': return 'Newest First';
      case 'oldest': return 'Oldest First';
      case 'brand-a-z': return 'Brand: A to Z';
      case 'age-young': return 'Age: Young to Old';
      case 'age-old': return 'Age: Old to Young';
      default: return 'Sort by';
    }
  };

  // Get unique values for filters
  const brands = [...new Set(categoryProducts.map(p => p.brand).filter(Boolean))];
  const clothTypes = [...new Set(categoryProducts.map(p => p.clothType).filter(Boolean))];
  const sizes = [...new Set(categoryProducts.flatMap(p => p.sizes || []))];

  const hasActiveFilters = selectedBrand || selectedClothType || selectedSize;

  return (
    <div className="shop-category">
      <img className="shopcategory-banner" src={props.banner} alt="" />
      
      <div className="shopcategory-indexSort">
        <div className="results-info">
          <p>
            <span>Showing 1-{Math.min(12, sortedProducts.length)}</span> out of {sortedProducts.length} products
          </p>
          {hasActiveFilters && (
            <button onClick={clearAllFilters} className="clear-all-filters">
              Clear All Filters
            </button>
          )}
        </div>
        
        <div className="shopcategory-sort">
          <div 
            className="sort-dropdown"
            onClick={() => setShowSortOptions(!showSortOptions)}
          >
            <span>{getSortDisplayText()}</span>
            <img 
              src={dropdown_icon} 
              alt="" 
              className={`dropdown-icon ${showSortOptions ? 'rotated' : ''}`}
            />
          </div>
          
          {showSortOptions && (
            <div className="sort-options">
              <div className="sort-section">
                <h4>Sort Options</h4>
                <div 
                  className={`sort-option ${sortBy === 'default' ? 'active' : ''}`}
                  onClick={() => handleSortChange('default')}
                >
                  Default
                </div>
                <div 
                  className={`sort-option ${sortBy === 'price-low-high' ? 'active' : ''}`}
                  onClick={() => handleSortChange('price-low-high')}
                >
                  Price: Low to High
                </div>
                <div 
                  className={`sort-option ${sortBy === 'price-high-low' ? 'active' : ''}`}
                  onClick={() => handleSortChange('price-high-low')}
                >
                  Price: High to Low
                </div>
                <div 
                  className={`sort-option ${sortBy === 'name-a-z' ? 'active' : ''}`}
                  onClick={() => handleSortChange('name-a-z')}
                >
                  Name: A to Z
                </div>
                <div 
                  className={`sort-option ${sortBy === 'name-z-a' ? 'active' : ''}`}
                  onClick={() => handleSortChange('name-z-a')}
                >
                  Name: Z to A
                </div>
                <div 
                  className={`sort-option ${sortBy === 'newest' ? 'active' : ''}`}
                  onClick={() => handleSortChange('newest')}
                >
                  Newest First
                </div>
                <div 
                  className={`sort-option ${sortBy === 'oldest' ? 'active' : ''}`}
                  onClick={() => handleSortChange('oldest')}
                >
                  Oldest First
                </div>
                <div 
                  className={`sort-option ${sortBy === 'brand-a-z' ? 'active' : ''}`}
                  onClick={() => handleSortChange('brand-a-z')}
                >
                  Brand: A to Z
                </div>
                <div 
                  className={`sort-option ${sortBy === 'age-young' ? 'active' : ''}`}
                  onClick={() => handleSortChange('age-young')}
                >
                  Age: Young to Old
                </div>
                <div 
                  className={`sort-option ${sortBy === 'age-old' ? 'active' : ''}`}
                  onClick={() => handleSortChange('age-old')}
                >
                  Age: Old to Young
                </div>
              </div>

              <div className="filter-section">
                <h4>Filter by Brand</h4>
                {brands.map(brand => (
                  <div 
                    key={brand}
                    className={`filter-option ${selectedBrand === brand ? 'active' : ''}`}
                    onClick={() => handleFilterChange('brand', brand)}
                  >
                    {brand}
                  </div>
                ))}
              </div>

              <div className="filter-section">
                <h4>Filter by Type</h4>
                {clothTypes.map(type => (
                  <div 
                    key={type}
                    className={`filter-option ${selectedClothType === type ? 'active' : ''}`}
                    onClick={() => handleFilterChange('clothType', type)}
                  >
                    {type}
                  </div>
                ))}
              </div>

              <div className="filter-section">
                <h4>Filter by Size</h4>
                {sizes.map(size => (
                  <div 
                    key={size}
                    className={`filter-option ${selectedSize === size ? 'active' : ''}`}
                    onClick={() => handleFilterChange('size', size)}
                  >
                    {size}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="shopcategory-products">
        {sortedProducts.length > 0 ? (
          sortedProducts.map((item) => (
            <Item
              key={item.id}
              id={item.id}
              name={item.name}
              image={item.image}
              new_price={item.new_price}
              old_price={item.old_price}
              description={item.description}
              sizes={item.sizes}
              clothType={item.clothType}
              brand={item.brand}
              date={item.date}
            />
          ))
        ) : (
          <div className="no-products">
            <h3>No products found</h3>
            <p>
              {hasActiveFilters 
                ? "Try adjusting your filters"
                : "No products available in this category"
              }
            </p>
            {hasActiveFilters && (
              <button onClick={clearAllFilters} className="clear-filters-btn">
                Clear All Filters
              </button>
            )}
          </div>
        )}
      </div>

      {sortedProducts.length > 12 && (
        <div className="shopcategory-loadmore">Explore More</div>
      )}
    </div>
  );
};
