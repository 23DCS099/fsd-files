import React, { useContext, useState, useEffect } from 'react';
import { ShopContext } from '../Context/ShopContext';
import { useParams, useNavigate } from 'react-router-dom';
import { Breadcrums } from '../Components/Breadcrums/Breadcrums';
import { ProductDisplay } from '../Components/ProductDisplay/ProductDisplay';
import { DescriptionBox } from '../Components/DescriptionBox/DescriptionBox';
import { RelatedProducts } from '../Components/RelatedProducts/RelatedProducts';

export const Product = () => {
  const { all_product, isLoading } = useContext(ShopContext);
  const { productId } = useParams();
  const navigate = useNavigate();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!isLoading && all_product.length > 0) {
      const foundProduct = all_product.find((e) => e.id === Number(productId));
      if (foundProduct) {
        setProduct(foundProduct);
      } else {
        // Product not found, redirect to shop after a delay
        setTimeout(() => {
          navigate('/shop');
        }, 2000);
      }
      setLoading(false);
    }
  }, [all_product, productId, isLoading, navigate]);

  if (isLoading || loading) {
    return (
      <div className="loading-container">
        <div className="loading-spinner"></div>
        <p>Loading product details...</p>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="error-container">
        <h2>Product Not Found</h2>
        <p>Redirecting to shop...</p>
      </div>
    );
  }

  return (
    <div className="product-page">
      <Breadcrums product={product} />
      <ProductDisplay 
        product={product} 
        description={product.description}
        sizes={product.sizes}
        clothType={product.clothType}
        brand={product.brand}
      />
      <DescriptionBox 
        description={product.description}
        clothType={product.clothType}
        brand={product.brand}
      />
      <RelatedProducts category={product.category} currentProductId={product.id} />
    </div>
  );
};
