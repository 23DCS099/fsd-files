import './App.css';
import { Navbar } from './Components/Navbar/Navbar';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { ShopCategory } from './Pages/ShopCategory';
import { Shop } from './Pages/Shop';
import { Product } from './Pages/Product';
import { Cart } from './Pages/Cart';
import { LoginSignup } from './Pages/LoginSignup';
import { Profile } from './Pages/Profile';
import { MyOrders } from './Pages/MyOrders';
import { TrackOrder } from './Pages/TrackOrder';
import { Footer } from './Components/Footer/Footer';
import men_banner from './Components/Assets/banner_mens.png';
import women_banner from './Components/Assets/banner_women.png';
import kid_banner from './Components/Assets/banner_kids.png';
import PaymentDone from './Pages/PaymentDone';
import { useState, useEffect } from 'react';

// Protected Route Component
const ProtectedRoute = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('auth-token');
    setIsAuthenticated(!!token);
    setIsLoading(false);
  }, []);

  if (isLoading) {
    return (
      <div className="loading-container">
        <div className="loading-spinner"></div>
        <p>Loading...</p>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  return children;
};

function App() {
  return (
    <div>
      <BrowserRouter>
        <Navbar />
        <Routes>
          {/* Public route for login/signup */}
          <Route path='/login' element={<LoginSignup />} />
          
          {/* Protected routes - require authentication */}
          <Route path='/' element={
            <ProtectedRoute>
              <Shop />
            </ProtectedRoute>
          } />
          <Route path='/mens' element={
            <ProtectedRoute>
              <ShopCategory banner={men_banner} category="men" />
            </ProtectedRoute>
          } />
          <Route path='/womens' element={
            <ProtectedRoute>
              <ShopCategory banner={women_banner} category="women" />
            </ProtectedRoute>
          } />
          <Route path='/kids' element={
            <ProtectedRoute>
              <ShopCategory banner={kid_banner} category="kid" />
            </ProtectedRoute>
          } />
          <Route path="/product/:productId" element={
            <ProtectedRoute>
              <Product />
            </ProtectedRoute>
          } />
          <Route path='/cart' element={
            <ProtectedRoute>
              <Cart />
            </ProtectedRoute>
          } />
          <Route path='/profile' element={
            <ProtectedRoute>
              <Profile />
            </ProtectedRoute>
          } />
          <Route path='/my-orders' element={
            <ProtectedRoute>
              <MyOrders />
            </ProtectedRoute>
          } />
          <Route path='/track-order/:orderId' element={
            <ProtectedRoute>
              <TrackOrder />
            </ProtectedRoute>
          } />

          {/* Payment success route */}
          <Route path='/payment-done' element={<PaymentDone />} />
          
          {/* Redirect any unknown routes to login */}
          <Route path='*' element={<Navigate to="/login" replace />} />
        </Routes>
        <Footer />
      </BrowserRouter>
    </div>
  );
}

export default App;
